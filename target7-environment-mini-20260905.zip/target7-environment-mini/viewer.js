import * as THREE from './vendor/three.module.min.js';

const canvas = document.querySelector('#scene');
const stage = document.querySelector('.stage');
const loadState = document.querySelector('#load-state');
const contract = await fetch('./scene-contract.json').then((response) => {
  if (!response.ok) throw new Error(`场景参数加载失败：${response.status}`);
  return response.json();
});

const scene = new THREE.Scene();
scene.background = new THREE.Color(contract.renderer.clearColor);

const projection = contract.camera.projection;
const camera = new THREE.PerspectiveCamera(
  projection.fovYDegrees,
  contract.canvas[0] / contract.canvas[1],
  projection.near,
  projection.far,
);
camera.position.fromArray(contract.camera.position);
camera.quaternion.fromArray(contract.camera.rotationXyzw);
camera.updateMatrixWorld();

const renderer = new THREE.WebGLRenderer({ canvas, antialias: contract.renderer.antialias });
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;
renderer.setClearColor(contract.renderer.clearColor, 1);

const textureLoader = new THREE.TextureLoader();

function loadTexture(path) {
  return textureLoader.loadAsync(path).then((texture) => {
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    return texture;
  });
}

async function addPlane({ texture: texturePath, size, position, opacity, alphaMode, renderOrder }, rotationX = 0) {
  const texture = await loadTexture(texturePath);
  const blend = alphaMode === 'blend';
  const material = new THREE.MeshBasicMaterial({
    map: texture,
    side: THREE.DoubleSide,
    transparent: blend,
    opacity,
    depthTest: true,
    depthWrite: !blend,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size[0], size[1]), material);
  mesh.position.fromArray(position);
  mesh.rotation.x = rotationX;
  mesh.renderOrder = renderOrder;
  scene.add(mesh);
}

const tasks = [
  ...contract.sky.planes.map((plane) => addPlane(plane)),
  addPlane(contract.ocean, THREE.MathUtils.degToRad(contract.ocean.rotationXDegrees)),
  ...contract.clouds.map((cloud) => addPlane({
    ...cloud,
    texture: `./assets/cloud/${cloud.name}.png`,
    alphaMode: 'blend',
  })),
];

try {
  await Promise.all(tasks);
  loadState.textContent = '当前运行资源已加载 · 3:2 固定画幅';
} catch (error) {
  loadState.textContent = error instanceof Error ? error.message : '资源加载失败';
  throw error;
}

function resizeAndRender() {
  const width = Math.max(1, Math.round(stage.clientWidth));
  const height = Math.max(1, Math.round(stage.clientHeight));
  renderer.setPixelRatio(Math.min(devicePixelRatio, contract.renderer.maximumPixelRatio));
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.render(scene, camera);
}

new ResizeObserver(resizeAndRender).observe(stage);
resizeAndRender();

for (const button of document.querySelectorAll('[data-view]')) {
  button.addEventListener('click', () => {
    for (const tab of document.querySelectorAll('[data-view]')) tab.classList.remove('is-active');
    for (const view of document.querySelectorAll('.view')) view.classList.remove('is-active');
    button.classList.add('is-active');
    document.querySelector(`#${button.dataset.view}`).classList.add('is-active');
    if (button.dataset.view === 'environment') requestAnimationFrame(resizeAndRender);
  });
}
