# Target7 环境最小复现包

这是一个自包含的静态审图包，只复现当前 Target7 的海水、云、天空和固定摄影机高度/位置。
它不依赖 Scene Engine，不包含岛屿模型、玩法对象、UI、动画或 production catalog。

## 运行

要求 Node.js 20+，无需安装依赖：

```bash
npm start
```

浏览器打开 `http://127.0.0.1:8080`。如需指定端口：

```bash
npm start -- 8090
```

## 固定参数

- 画幅：`1536 × 1024`（3:2）。
- 摄影机位置：`[0, 50, 75]`，其中世界高度 `Y = 50`。
- 观察点：`[0, 0, 3.5927526193]`。
- 俯角：`35.00005766383532°`；距离：`87.17221448654662`。
- 透视：`FOV 34°`、`near 0.1`、`far 2400`。
- 海面：`420 × 273`，世界位置 `[0, -1.45, 8]`。
- 天空、地平线、雾和 12 张云片的尺寸、位置、透明度及渲染顺序见
  [`scene-contract.json`](scene-contract.json)。

## 参考图分工

| 文件 | 用途 |
| --- | --- |
| `references/target6-3.png` | **岛屿区域参考图**：岛形、地块布局、海岸线、地形层级与像素化材质语言。 |
| `references/target10.png` | **海面区域参考图**：大范围海面色带、深浅水过渡、地平线、天空高度与云带分布。 |

两张参考图都保留原始 `1536 × 1024` 内容；SHA-256 和机器可读角色写在
[`scene-contract.json`](scene-contract.json) 的 `references` 中。

## 来源与边界

- 天空、海面和云资源来自 Missile War Arts 当前 promoted 环境资源。
- 摄影机与环境相对位置来自 `prefabs/baseline-composition.js` 和三个 environment owner。
- `target6-3.png` 来自仓内保留的完整同源参考；`target10.png` 来自 `art-direction/target7/`。
- 本包状态为 `study`，用于复现和沟通，不替代正式 Prefab Baseline 验收面。
